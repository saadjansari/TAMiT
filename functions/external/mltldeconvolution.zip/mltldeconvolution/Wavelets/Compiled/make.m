% Script for compiling all C files in this directory
%
% (c) Cedric Vonesch, 2007.02.13

mex DownSampleDim.c
mex UpSampleDim.c
mex FilterSep.c